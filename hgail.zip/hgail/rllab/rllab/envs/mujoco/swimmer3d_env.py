from .swimmer_env import SwimmerEnv

class Swimmer3DEnv(SwimmerEnv):
    FILE = 'swimmer3d.xml'