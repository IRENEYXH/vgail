from sandbox.rocky.tf.core.parameterized import Parameterized

class QFunction(Parameterized):
    pass
